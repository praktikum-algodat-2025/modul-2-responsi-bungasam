public class Node {
    public int nomorPelanggan;
    public BukuStack buku;
    public Node next;
    
    public Node(int nomorPelanggan) {
        this.nomorPelanggan = nomorPelanggan;
        this.buku = new BukuStack();
        this.next = null;
    }
}
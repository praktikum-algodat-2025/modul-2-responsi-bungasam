public class Main {
    public static void main(String[] args) {
        AntrianPelanggan antrian = new AntrianPelanggan();
        
        System.out.println("=== LIST SEMUA PELANGGAN ===");
        antrian.enqueue();
        antrian.enqueue(); 
        antrian.enqueue();
        antrian.enqueue();
        antrian.display();
        
        System.out.println("=== Hapus pelanggan ke-1 ===");
        antrian.dequeue();
        antrian.display();
        
        System.out.println("=== Tambah pelanggan baru ===");
        antrian.enqueue();
        antrian.display();
        
        System.out.println("=== Pop 2 buku dari pelanggan ke-1 ===");
        antrian.popBuku(1, 2);
        antrian.display();
    }
}

class AntrianPelanggan {
    public Node head;
    public int count;
    
    public AntrianPelanggan() {
        this.head = null;
        this.count = 0;
    }
    
    public void enqueue() {
        count++;
        Node newNode = new Node(count);
        
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        
        tambahBukuDefault(newNode);
    }
    
    public void dequeue() {
        if (head == null) {
            System.out.println("Tidak ada pelanggan");
            return;
        }
        head = head.next;
        
        updateNomorPelanggan();
        count--;
    }
    
    public void popBuku(int nomorPelanggan, int jumlahPop) {
        Node current = head;
        
        while (current != null) {
            if (current.nomorPelanggan == nomorPelanggan) {
                for (int i = 0; i < jumlahPop; i++) {
                    String bukuDiPop = current.buku.pop();
                    if (bukuDiPop != null) {
                        System.out.println();
                    } else {
                        System.out.println("  Tidak ada buku lagi");
                        break;
                    }
                }
                return;
            }
            current = current.next;
        }
    }
    
    public void updateNomorPelanggan() {
        Node current = head;
        int newNomor = 1;
        
        while (current != null) {
            current.nomorPelanggan = newNomor++;
            current = current.next;
        }
    }
    
    public void tambahBukuDefault(Node pelanggan) {
        int nomor = pelanggan.nomorPelanggan;
        
        if (nomor == 1) {
            pelanggan.buku.push("Technical Analysis");
            pelanggan.buku.push("Fundamental Analysis");
            pelanggan.buku.push("Data Analysis");
        } else if (nomor == 2) {
            pelanggan.buku.push("Clean Code");
            pelanggan.buku.push("The Pragmatic Programmer");
            pelanggan.buku.push("Design Patterns");
        } else if (nomor == 3) {
            pelanggan.buku.push("Dune");
            pelanggan.buku.push("Foundation");
             pelanggan.buku.push("Hyperion");
            pelanggan.buku.push("Neuromancer");
        } else if (nomor == 4) {
            pelanggan.buku.push("Sapiens: A Brief History of Humankind");
            pelanggan.buku.push("Guns, Germs, and Steel");
            pelanggan.buku.push("The Silk Roads");
        } else {
            pelanggan.buku.push("Tangkuban Perahu");
            pelanggan.buku.push("Timun Mas");
            pelanggan.buku.push("Resep Ayam Goyeng Upin Ipin");
        }

    }
    
    public void display() {
        if (head == null) {
            System.out.println("Tidak ada pelanggan");
            return;
        }
        
        Node current = head;
        while (current != null) {
            System.out.println("Pelanggan ke-" + current.nomorPelanggan);
            current.buku.displayBuku();
            current = current.next;
            System.out.println();
        }
    }
}
public class BukuStack {
    public BukuNode top;
    
    public BukuStack() {
        this.top = null;
    }
    
    public void push(String judulBuku) {
        BukuNode newNode = new BukuNode(judulBuku);
        if (top == null) {
            top = newNode;
        } else {
            newNode.next = top;
            top = newNode;
        }
    }
    
    public String pop() {
        if (top == null) {
            return null;
        }
        String judul = top.judulBuku;
        top = top.next;
        return judul;
    }
    
    public void displayBuku() {
        BukuNode current = top;
        while (current != null) {
            System.out.println("  - " + current.judulBuku);
            current = current.next;
        }
    }
}

class BukuNode {
    public String judulBuku;
    public BukuNode next;
    
    public BukuNode(String judulBuku) {
        this.judulBuku = judulBuku;
        this.next = null;
    }
}